export const top = () =>
	window.pageYOffset || document.documentElement.scrollTop;
export const left = () =>
	window.pageXOffset || document.documentElement.scrollLeft;
