module.exports = {
	"extends": ["@wordpress/stylelint-config", "./gravity-forms"],
}
