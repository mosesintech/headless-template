import ready from './core/ready';

ready();
