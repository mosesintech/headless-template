// breakpoint settings

export const MOBILE_BREAKPOINT = 768;
