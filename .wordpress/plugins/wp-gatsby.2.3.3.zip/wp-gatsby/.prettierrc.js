module.exports = {
	arrowParens: "avoid",
	semi: false,
}
