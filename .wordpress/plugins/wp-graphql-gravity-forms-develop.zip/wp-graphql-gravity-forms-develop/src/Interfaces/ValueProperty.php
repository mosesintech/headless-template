<?php
/**
 * Interface for Gravity Forms entry value property.
 *
 * @package WPGraphQLGravityForms\Interfaces
 * @since 0.5.0
 */

namespace WPGraphQLGravityForms\Interfaces;

use GF_Field;

/**
 * Interface - ValueProperty
 */
interface ValueProperty { }
