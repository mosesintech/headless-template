=== WPGraphQL for Gravity Forms ===
Contributors: kellenmace, mtdbyanechko, justlevine, tinytoolbox
Tags: GraphQL, Gatsby, Headless, GF, Gravity, Forms, WPGraphQL, 
Requires at least: 5.4.1
Tested up to: 5.8.1
Requires PHP: 7.4
Requires Gravity Forms: 2.5.0+
Requires WPGraphQL: 1.0.0+
Stable tag: 0.8.2
Maintained at: https://github.com/harness-software/wp-graphql-gravity-forms
License: GPL-3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

== Description ==
Adds Gravity Forms functionality to the WPGraphQL schema. For more information, see [README.md](https://github.com/harness-software/wp-graphql-gravity-forms/blob/main/README.md)

== Upgrade Notice == 
== Frequently Asked Questions ==
== Screenshots ==

== Changelog ==
See [Release Notes](https://github.com/harness-software/wp-graphql-gravity-forms/releases)
